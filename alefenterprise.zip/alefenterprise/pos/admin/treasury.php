<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');
require_once('partials/_analytics.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
	
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
	  
    <?php
    require_once('partials/_topnav.php');

    
                  $ret = "SELECT * FROM `rpos_treasury` ORDER BY `rpos_treasury`.`created_at` DESC";
                  $stmt = $mysqli->prepare($ret);
                  $stmt->execute();
                  $res = $stmt->get_result();
                  $total_income = 0;
                  $total_exp = 0;
                  while ($trans = $res->fetch_object()) {
                    $total_income += $trans->income;
                    $total_exp += $trans->expense;
                  }
              
    
    ?>
	
	  
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        
          <!-- Card stats -->
          <div class="row ">
          <div class="col-xl-12 col-lg-12">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body text-center">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title h2 text-uppercase mb-0 ">Cash In Hand</h5>
                      <span class="h1 font-weight-bold mb-0"><b> <?php echo number_format(($total_income - $total_exp),2,'.',','); ?></b></span>
                    </div>
                    
                  </div>
                </div>
              </div>
            </div>
            </div>
            <div class="row mt-2">
          <div class="col-xl-12 col-lg-12">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body text-center">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title h2 text-uppercase mb-0 ">Other Asset</h5>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </div>
          <div class="row">
          <?php  
          $ret = "SELECT * FROM  rpos_products WHERE NOT (prod_id = 'forMakePayment')";
          $stmt = $mysqli->prepare($ret);
          $stmt->execute();
          $res = $stmt->get_result();
          while ($prod = $res->fetch_object()) {
      ?> 
            <div class="col-xl-4 col-lg-8 md-2 mt-2">
              <div class="card card-stats mb-2 mb-xl-0">
              
                <div class="card-body ">
                  <div class="row">
                    <div class="col">
                    <?php  
                        $id = $prod->prod_id;
                        $TotalUnload_from = 0;
                        $TotalSell = 0;
                        $aret = "SELECT * FROM  rpos_stock WHERE prod_id = '$id'";
                        $astmt = $mysqli->prepare($aret);
                        $astmt->execute();
                        $ares = $astmt->get_result();
                        while ($aprod = $ares->fetch_object()) {
                          $TotalUnload_from += $aprod->unload_from;
                          $TotalSell += $aprod->sell;
                        }
                    ?> 
                      <h5 class="card-title h2 text-uppercase text-muted mb-0"><?php echo $prod->prod_name; ?></h5>
                      <span class="h2 font-weight-bold mb-0">Total sell: <?php echo $TotalSell; ?> Units</span><br>
                      <span class="h2 font-weight-bold mb-0">In Stock: <b><?php echo $TotalUnload_from - $TotalSell; ?></b> Units</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php }?>
          </div>

          <div class="row mt-2">
        <div class="col">
          <div class="card shadow">
          <div class="card-header border-0">

              <h3 class="flex">Transaction Summary of Treasury</h3>
              <a target="_blank" href="supplier_summery_print.php?com_id=<?php //echo $com_id; ?>" >
                          <button class="btn btn-sm btn-info">
                            <i class="fas fa-print"></i>
                            Print
                          </button>
                        </a>
            </div>

            <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">Date</th>
                    <th scope="col">Description</th>
                    <th scope="col">Income</th>
                    <th scope="col">Expenses</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $ret = "SELECT * FROM `rpos_treasury` ORDER BY `rpos_treasury`.`created_at` DESC";
                $stmt = $mysqli->prepare($ret);
                $stmt->execute();
                $res = $stmt->get_result();
                  while ($trans = $res->fetch_object()) {
                  ?>
                        <tr>
                        
                        <td><?php echo date('d/M/Y g:i a', strtotime($trans->created_at)); ?></td>
                        <td scope="row"><?php echo $trans->trn_des; ?></td>
                        <td>
                            <?php 
                                echo $trans->income; 
                            ?>
                        </td>
                        <td>
                            <?php 
                                echo $trans->expense; 
                            ?>
                        </td>
                        
                        </tr>
                    <?php } ?>

                    <tr>
                        <td></td>
                        <td><b>Total</b></td>
                        <td><b><?php echo $total_income; ?></b></td>
                        <td><b><?php echo $total_exp; ?></b></td>
                    </tr>
                   
                </tbody>
            </table>
            </div>
          </div>
        </div>
      </div>

          
        </div>
      </div>
    </div>
	  
    <!-- Page content -->
    
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>
