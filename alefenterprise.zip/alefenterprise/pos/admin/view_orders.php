<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
    <meta name="author" content="MartDevelopers Inc">
    <title>M/S Alef Enterprise</title>
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/icons/favicon-16x16.png">
    <link rel="manifest" href="assets/img/icons/site.webmanifest">
    <link rel="mask-icon" href="assets/img/icons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
    <link href="assets/css/bootstrap.css" rel="stylesheet" id="bootstrap-css">
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/jquery.js"></script>
    <style>
        body {
            margin-top: 20px;
        }
    </style>
</head>
</style>
<?php
$cus_id = $_GET['cus_id'];
$ret = "SELECT * FROM  rpos_orders WHERE customer_id = '$cus_id'";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$res = $stmt->get_result();
$total = 0;
$sub_total = 0;
$total_paid = 0;

//get customer info
$cret = "SELECT * FROM  rpos_customers WHERE customer_id = '$cus_id'";
$cstmt = $mysqli->prepare($cret);
$cstmt->execute();
$cres = $cstmt->get_result();
while ($iteration = $cres->fetch_object()) {
   $customer_name = $iteration->customer_name;
   $customer_email = $iteration->customer_email;
   $customer_phone = $iteration->customer_phoneno;
}


//get total paid balance

$pret = "SELECT * FROM  rpos_payments WHERE customer_id = '$cus_id'";
$pstmt = $mysqli->prepare($pret);
$pstmt->execute();
$pres = $pstmt->get_result();
$pa_amt[100] = 0;
$i = 0;
while ($iteration = $pres->fetch_object()) {
    $pa_amt[$i] = $iteration->paid_amt;
    $total_paid += $iteration->paid_amt;
    $i++;
}

?>

    <body>
        <div class="container">
            <div class="row">
                <div id="Receipt" class="well col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3">
                <div class="row">
                        <div class="text-center">
                            <h3>M/S Alef Enterprise</h3>
                            <h5> Mobile: 01714-673650</h5>
                            <h5> Aruapara, Kushtia</h5>
                            
                        </div>
                        <hr>
                        </span>
                        <div class="text-center">
                            <h3>Cash Mamo</h3>
                        </div>
                        </span>
                </div>    
                <div class="row">
                        <div class="col-xs-6 col-sm-6 col-md-6">
                            <address>
                                <strong>Customer Name: <?php echo $customer_name;?></strong>
                                <br>
                                Mobile: <?php echo $customer_phone;?>
                                <br>
                                Address: <?php echo $customer_email;?>.
                            </address>
                        </div>
                        <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                            <p>
                                <em>Date:<?php echo date('d/M/Y', time()); ?> </em>
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Item</th>
                                    <th>Quantity</th>
                                    <th class="text-center">Unit Price</th>
                                    <th class="text-center">Cost</th>
                                    <th class="text-center">Paid</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $it = 0;
                                    while ($order = $res->fetch_object()) {
                                    $total = ($order->prod_price * $order->prod_qty);
                                    $sub_total += $total;
                                ?>
                                <tr>
                                    <td><?php echo date('d/M/Y', strtotime($order->created_at)); ?></td>
                                    <td class="col-md-9"><em> <?php echo $order->prod_name; ?> </em></h4>
                                    </td>
                                    <td class="col-md-1" style="text-align: center"> <?php echo $order->prod_qty; ?></td>
                                    <td class="col-md-1 text-center">$<?php echo $order->prod_price; ?></td>
                                    <td class="col-md-1 text-center">$<?php echo $total; ?></td>
                                    <td class="col-md-1 text-center">$<?php echo $order->paid_amt; ?></td>
                                </tr>
                                <?php 
                                    }
                                    ?>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    
                                    <td class="text-right">
                                        <p>
                                            <strong>Total:</strong>
                                        </p>
                                        
                                    </td>
                                    <td class="text-center">
                                        <p>
                                            <strong>$<?php echo $sub_total; ?></strong>
                                        </p>
                                        
                                       
                                    </td>
                                    <td class="text-right">
                                    <p>
                                            <strong>$<?php echo $total_paid; ?></strong>
                                        </p>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <?php    //check balance is grater or less
                                    if($sub_total - $total_paid >= 0 ){     //positive mean DUE
                                    ?>
                                    <td class="text-right">
                                        <h4><strong>DUE:</strong></h4>
                                    </td>
                                    <td class="text-center text-danger">
                                        <h4><strong>$<?php echo $sub_total - $total_paid; ?></strong></h4>
                                    </td>
                                    <?php } 
                                        else{
                                    ?>
                                        <td class="text-right">
                                            <h4><strong>ADVANCE:</strong></h4>
                                        </td>
                                        <td class="text-center text-danger">
                                            <h4><strong>$<?php echo $sub_total - $total_paid * -1; ?></strong></h4>
                                        </td>
                                    <?php } ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="well col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3">
                    <button id="print" onclick="printContent('Receipt');" class="btn btn-success btn-lg text-justify btn-block">
                        Print <span class="fas fa-print"></span>
                    </button>
                </div>
            </div>
        </div>
    </body>

</html>
<script>
    function printContent(el) {
        var restorepage = $('body').html();
        var printcontent = $('#' + el).clone();
        $('body').empty().html(printcontent);
        window.print();
        $('body').html(restorepage);
    }
</script>