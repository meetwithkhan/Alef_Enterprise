<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');

check_login();

//Add Customer
if (isset($_POST['addCustomer'])) {
  //Prevent Posting Blank Values
  
  if (empty($_POST["customer_phoneno"]) || empty($_POST["customer_name"]) || empty($_POST['customer_email']) || empty($_POST['customer_password'])) {
    $err = "Blank Values Not Accepted";
  } else {
    $customer_name = $_POST['customer_name'];
    $customer_phoneno = $_POST['customer_phoneno'];
    $customer_email = $_POST['customer_email'];
    $customer_password = sha1(md5($_POST['customer_password'])); //Hash This 
    $customer_id = $_POST['customer_id'];

    //Insert Captured information to a database table
    $postQuery = "INSERT INTO rpos_customers (customer_id, customer_name, customer_phoneno, customer_email, customer_password) VALUES(?,?,?,?,?)";
    $postStmt = $mysqli->prepare($postQuery);
    
    //bind paramaters
    $rc = $postStmt->bind_param('sssss', $customer_id, $customer_name, $customer_phoneno, $customer_email, $customer_password);
    $postStmt->execute();
    
    //declare a varible which will be passed to alert function
    if ($postStmt) {
      $success = "Customer Added" && header("refresh:1; url=customes.php");
    } else {
      $err = "Please Try Again Or Try Later";
    }
  }
}

require_once('partials/_head.php');
?>

<body>

  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
    <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
          <div class="card-header border-0">
              <h3>Stock Management</h3>
            </div>
            <div class="card-body justify-content-center">
            
              <form action="stock_from_company.php" method="POST" >
                <div class="form-row">
                  <div class="col-md-6">
                    <input type="submit" value="From Company" class="btn btn-success" value="">
                  </div>
                </div>
              </form>
              <form action="abba_get_from.php" method="POST" >
                <div class="form-row">
                  <div class="col-md-6 mt-4">
                    <input type="submit" value="Other Source" class="btn btn-primary" value="">
                  </div>
                </div>
              </form>
              <form action="abba_transaction_summary.php" method="POST" >
                <div class="form-row">
                  <div class="col-md-6 mt-4">
                    <input type="submit" value="Summary" class="btn btn-info" value="">
                  </div>
                </div>
              </form>
            
          </div>    
          </div>
        </div>
      </div>
      
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>
