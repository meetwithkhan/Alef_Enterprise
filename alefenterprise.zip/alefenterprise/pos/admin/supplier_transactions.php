<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');

check_login();

$com_id = $_GET['com_id'];

//get customer info
$cret = "SELECT * FROM  rpos_company WHERE com_id = '$com_id'";
$cstmt = $mysqli->prepare($cret);
$cstmt->execute();
$cres = $cstmt->get_result();

while ($iteration = $cres->fetch_object()) {
   $com_name = $iteration->com_name;
}

require_once('partials/_head.php');
?>

<body>

  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
    <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
          <div class="card-header border-0">

              <h3 class="flex">Transaction Summary of <?php echo $com_name; ?> </h3>
              <a target="_blank" href="supplier_summery_print.php?com_id=<?php echo $com_id; ?>" >
                          <button class="btn btn-sm btn-info">
                            <i class="fas fa-print"></i>
                            Print
                          </button>
                        </a>
            </div>

            <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">Date</th>
                    <th scope="col">Description</th>
                    <th scope="col">Cost</th>
                    <th scope="col">Paid</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                  $ret = "SELECT * FROM `rpos_company_transaction` WHERE com_id = '$com_id' ORDER BY `rpos_company_transaction`.`created_at` ASC";
                  $stmt = $mysqli->prepare($ret);
                  $stmt->execute();
                  $res = $stmt->get_result();
                  $total_paid = 0;
                  $Sumof_total_cost = 0;
                  while ($trans = $res->fetch_object()) {
                    $total_paid += $trans->paid_amt;
                    $Sumof_total_cost += $trans->total_cost;
                    
                  ?>
                        <tr>
                        
                        <td><?php echo date('d/M/Y g:i a', strtotime($trans->created_at)); ?></td>
                        <td scope="row"><?php echo $trans->prod_name; ?></td>
                        <td>
                            <?php 
                                echo $trans->total_cost; 
                            ?>
                        </td>
                        <td>
                            <?php 
                                echo $trans->paid_amt; 
                            ?>
                        </td>
                        
                        </tr>
                    <?php } ?>

                    <tr>
                        <td></td>
                        <td><b>Total</b></td>
                        <td><b><?php echo $Sumof_total_cost; ?></b></td>
                        <td><b><?php echo $total_paid; ?></b></td>
                    </tr>
                    <tr>
                    <td></td>
                    <td></td>
                    <?php    //check balance is grater or less
                                    if($Sumof_total_cost - $total_paid >= 0 ){     //positive mean DUE
                                    ?>
                                    <td >
                                        <h4><strong>DUE:</strong></h4>
                                    </td>
                                    <td class=" text-danger">
                                        <h4><strong>$<?php echo $Sumof_total_cost - $total_paid; ?></strong></h4>
                                    </td>
                                    <?php } 
                                        else{
                                    ?>
                                        <td >
                                            <h4><strong>ADVANCE:</strong></h4>
                                        </td>
                                        <td class="text-danger">
                                            <h4><strong>$<?php echo $Sumof_total_cost - $total_paid * -1; ?></strong></h4>
                                        </td>
                                    <?php } ?>
                  </tr>
                </tbody>
            </table>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>
