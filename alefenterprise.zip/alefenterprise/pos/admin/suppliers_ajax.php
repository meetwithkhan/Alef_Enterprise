<?php
include('config/pdoconfig.php');

if (!empty($_POST["comName"])) {
    $id = $_POST['comName'];
    $stmt = $DB_con->prepare("SELECT * FROM  rpos_company WHERE com_name = :id");
    $stmt->execute(array(':id' => $id));
?>

<?php
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
?>
<?php echo htmlentities($row['com_id']); ?>
<?php
    }
}
