<?php echo $pa_amt[1];?>

empty($_POST["lab_cost"]) || 