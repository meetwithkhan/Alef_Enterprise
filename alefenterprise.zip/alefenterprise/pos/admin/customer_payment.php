<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');

$customerName = "";

check_login();
if (isset($_POST['make'])) {
  //Prevent Posting Blank Values
  if (empty($_POST["customer_name"]) || empty($_POST['paid_amt'])) {
    $err = "Blank Values Not Accepted";
  } else {
    $pay_id = $_POST['pay_id'];
    $customer_id = $_POST['customer_id'];
    $customerName = $_POST['customer_name'];
    $paid_amt = $_POST['paid_amt'];


    // //get customer info
    // $cret = "SELECT * FROM  rpos_customers WHERE customer_id = '$customer_id'";
    // $cstmt = $mysqli->prepare($cret);
    // $cstmt->execute();
    // $cres = $cstmt->get_result();

    // while ($iteration = $cres->fetch_object()) {
    //   $customer_name = $iteration->customer_name;
    // }

    $pay_des = $paid_amt . "tk paid by ".$customerName;

    $postQuery = "INSERT INTO rpos_payments (pay_id, customer_id, paid_amt, pay_des) VALUES(?,?,?,?)";
    $postStmt = $mysqli->prepare($postQuery);
    $rc = $postStmt->bind_param('ssss', $pay_id, $customer_id,$paid_amt, $pay_des);
    $postStmt->execute();


    //Insert Captured information to a orders table
    $postQuery = "INSERT INTO rpos_orders (prod_qty, order_id, order_code, customer_id, customer_name, prod_id, prod_name, prod_price, paid_amt, order_status) VALUES(?,?,?,?,?,?,?,?,?,?)";
    $postStmt = $mysqli->prepare($postQuery);
    //bind paramaters
    $prod_id = "forMakePayment"; //dummy parameter for adding make payment to order list 
    $prod_qty = 0;
    $prod_price = 0;
    $order_status = "Paid";
    $rc = $postStmt->bind_param('ssssssssss', $prod_qty, $pay_id, $pay_id, $customer_id, $customerName, $prod_id, $pay_des, $prod_price, $paid_amt, $order_status);
    $postStmt->execute();

    //declare a varible which will be passed to alert function
    if ($postStmt) {
    // if successful then add sell amount to treasury table
    $trn_id = $_POST['trn_id'];
    $postQuery = "INSERT INTO rpos_treasury (trn_id, trn_des, income, expense) VALUES(?,?,?,?)";
    $postStmt = $mysqli->prepare($postQuery);
    //bind paramaters
    $exp =0;
    $rc = $postStmt->bind_param('ssss', $trn_id, $pay_des, $paid_amt, $exp);
    $postStmt->execute();/*
     <input type="hidden" name="trn_id" value="<?php echo $trnid; ?>" class="form-control">;*/
      $success = "Order Submitted" && header("refresh:1; url=customes.php");
    } else {
      $err = "Please Try Again Or Try Later";
    }
  }
}
require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
    <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
            <a href="add_customer.php" class="btn btn-outline-success">
                <i class="fas fa-user-plus"></i>
                Add New Customer
              </a>
            </div>
            <div class="card-body">
              <form method="POST" enctype="multipart/form-data">
                <div class="form-row">

                  <div class="col-md-4">
                    <label>Customer Name</label>
                    <select class="form-control" name="customer_name" id="custName" onChange="getCustomer(this.value)">
                      <option value="">Select Customer Name</option>
                      <?php
                      //Load All Customers
                      $ret = "SELECT * FROM  rpos_customers ";
                      $stmt = $mysqli->prepare($ret);
                      $stmt->execute();
                      $res = $stmt->get_result();
                      while ($cust = $res->fetch_object()) {
                      ?>
                        <option><?php  echo $cust->customer_name;?></option>
                      <?php } ?>
                    </select>
                    <input type="hidden" name="pay_id" value="<?php echo $payid; ?>" class="form-control">
                    <input type="hidden" name="trn_id" value="<?php echo $trnid; ?>" class="form-control"> 
                  </div>

                  <div class="col-md-4">
                    <label>Customer ID</label>
                    <input type="text" name="customer_id" readonly id="customerID" class="form-control">
                  </div>
                </div>
                  <div class="form-row">
                    <div class="col-md-6 mt-2">
                      <label>Paid Amount</label>
                      <input type="text"  name="paid_amt" placeholder="$ 1000" class="form-control">
                    </div>
                    
                  </div>
                
                <br>
                <div class="form-row">
                  <div class="col-md-6">
                    <input type="submit" name="make" value="Make Diposite" class="btn btn-success" >
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>