<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');

check_login();
if (isset($_POST['make'])) {
  //Prevent Posting Blank Values
  if (empty($_POST["com_name"]) || empty($_POST['paid_amt']) || empty($_POST['des'])) {
    $err = "Blank Values Not Accepted";
  } else {
    $trn_id = $_POST['trn_id'];
    $com_id = $_POST['com_id'];
    $paid_amt = $_POST['paid_amt'];
    $pay_des = $_POST['des'];
    $total_cost = 0;

    $postQuery = "INSERT INTO rpos_company_transaction (trn_id, com_id, paid_amt, prod_name, total_cost) VALUES(?,?,?,?,?)";
    $postStmt = $mysqli->prepare($postQuery);
    $rc = $postStmt->bind_param('sssss', $trn_id, $com_id,$paid_amt, $pay_des, $total_cost);

    $postStmt->execute();


    //declare a varible which will be passed to alert function
    if ($postStmt) {
      $success = "Order Submitted" && header("refresh:1; url=suppliers.php");
    } else {
      $err = "Please Try Again Or Try Later";
    }
  }
}
require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
    <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3>Please Fill All Fields</h3>
            </div>
            <div class="card-body">
              <form method="POST" enctype="multipart/form-data">
              <div class="form-row">
                  <div class="col-md-6">
                    <label>Supplier Name</label>
                    <select class="form-control" name="com_name" id="comName" onChange="getSupplier(this.value)">
                      <option value="">Supplier Name</option>
                      <?php
                      //Load All suppliers
                      $ret = "SELECT * FROM  rpos_company ";
                      $stmt = $mysqli->prepare($ret);
                      $stmt->execute();
                      $res = $stmt->get_result();
                      while ($com = $res->fetch_object()) {
                      ?>
                        <option><?php echo $com->com_name; ?></option>
                      <?php } ?>
                    </select>
                    <input type="hidden" name="trn_id" value="<?php echo $trnid; ?>" class="form-control">
                  </div>
                  <div class="col-md-6">
                      <label>Supplier ID</label>
                      <input type="text" name="com_id" readonly id="comID" class="form-control">
                  </div>
                      </div>
                <div class="form-row">
                    <div class="col-md-6 mt-2">
                        <label>Paid Amount</label>
                        <input type="text"  name="paid_amt" placeholder="$ 1000" class="form-control">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-md-6 mt-2">
                        <label>Description</label>
                        <input type="text"  name="des"  class="form-control">
                    </div>
                </div>
                <br>
                <div class="form-row">
                  <div class="col-md-6">
                    <input type="submit" name="make" value="Make Diposite" class="btn btn-success" >
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>