<?php
include('config/pdoconfig.php');

if (!empty($_POST["prodName"])) {
    $id = $_POST['prodName'];
    $stmt = $DB_con->prepare("SELECT * FROM  rpos_products WHERE prod_name = :id");
    $stmt->execute(array(':id' => $id));
?>

<?php
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
?>
<?php echo htmlentities($row['prod_id']); ?>
<?php
    }
}
