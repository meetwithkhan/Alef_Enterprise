<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');
require_once('partials/_analytics.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
	
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
	  
    <?php
    require_once('partials/_topnav.php');
    
    ?>
	
	  
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
      <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        
          <!-- Card stats -->
          <div class="row">
          <?php  
          $ret = "SELECT * FROM  rpos_products WHERE NOT (prod_id = 'forMakePayment')";
          $stmt = $mysqli->prepare($ret);
          $stmt->execute();
          $res = $stmt->get_result();
          while ($prod = $res->fetch_object()) {
      ?> 
            <div class="col-xl-4 col-lg-8 md-2 mt-2">
              <div class="card card-stats mb-2 mb-xl-0">
              
                <div class="card-body ">
                  <div class="row">
                    <div class="col">
                    <?php  
                        $id = $prod->prod_id;
                        $TotalUnload_from = 0;
                        $TotalSell = 0;
                        $aret = "SELECT * FROM  rpos_stock WHERE prod_id = '$id'";
                        $astmt = $mysqli->prepare($aret);
                        $astmt->execute();
                        $ares = $astmt->get_result();
                        while ($aprod = $ares->fetch_object()) {
                          $TotalUnload_from += $aprod->unload_from;
                          $TotalSell += $aprod->sell;
                        }
                    ?> 
                      <h5 class="card-title h2 text-uppercase text-muted mb-0"><?php echo $prod->prod_name; ?></h5>
                      <span class="h2 font-weight-bold mb-0">Total sell: <?php echo $TotalSell; ?> Units</span><br>
                      <span class="h2 font-weight-bold mb-0">In Stock: <b><?php echo $TotalUnload_from - $TotalSell; ?></b> Units</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php }?>
          </div>

          
        </div>
      </div>
    </div>
	  
    <!-- Page content -->
    
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>
