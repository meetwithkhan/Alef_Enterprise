<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');

check_login();
if (isset($_POST['make'])) {
  //Prevent Posting Blank Values
  if (empty($_POST["trans_cost"])) {
    $err = "Blank Values Not Accepted";
  } else {
    $trn_id = $_POST['trn_id'];
    $com_id = $_POST['com_id'];
    $prod_id  = $_POST['prod_id'];
    $prod_name = $_POST['prod_name'];
    $prod_price = $_POST['prod_price'];
    $prod_qty = $_POST['prod_qty'];
    $lab_cost = $_POST['lab_cost'];
    $trans_cost = $_POST['trans_cost'];
    $total_cost = ($prod_price * $prod_qty) + $lab_cost + $trans_cost;
    $paid_amt = 0;

    //Insert Captured information to a database table
    //$postQuery = "INSERT INTO rpos_company_transaction (trn_id, com_id, prod_id, prod_name, prod_qty, prod_price, trans_cost, lab_cost, total_cost, paid_amt) VALUES(?,?,?,?,?,?,?,?,?,?)";
    $postQuery = "INSERT INTO rpos_company_transaction (trn_id, com_id, prod_id, prod_name, prod_qty, prod_price, trans_cost, lab_cost, total_cost, paid_amt) VALUES(?,?,?,?,?,?,?,?,?,?)";
    $postStmt = $mysqli->prepare($postQuery);
    //bind paramaters
    $rc = $postStmt->bind_param('ssssssssss',$trn_id, $com_id, $prod_id, $prod_name, $prod_qty, $prod_price, $trans_cost, $lab_cost, $total_cost, $paid_amt);
    $postStmt->execute();
    //declare a varible which will be passed to alert function
    if ($postStmt) {
       // if successful then add sell to stocks table
      $aQuery = "INSERT INTO rpos_stock (prod_id, stock_des, unload_from, sell) VALUES(?,?,?,?)";
      $aStmt = $mysqli->prepare($aQuery);
      //bind paramaters
      $sell = 0;
      $stock_des = "Product came form supplier.";
      $arc = $aStmt->bind_param('ssss', $prod_id, $stock_des, $prod_qty, $sell);
      $aStmt->execute();

      $success = "Order Submitted" && header("refresh:1; url=stocks_summary.php");
    } else {
      $err = "Please Try Again Or Try Later";
    }
  }
}
require_once('partials/_head.php');
?>

<body>
  <!-- Sidenav -->
  <?php
  require_once('partials/_sidebar.php');
  ?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <?php
    require_once('partials/_topnav.php');
    ?>
    <!-- Header -->
    <div style="background-image: url(assets/img/theme/restro00.jpg); background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
    <span class="mask bg-gradient-dark opacity-8"></span>
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <!-- Table -->
      <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <a href="add_suppliers.php" class="btn btn-outline-success">
                <i class="fas fa-user-plus"></i>
                Add New Supplier
              </a>
            </div>
            <div class="card-body">
              <form method="POST" enctype="multipart/form-data" >
                <div class="form-row">
                  <div class="col-md-6">
                    <label>Supplier Name</label>
                    <select class="form-control" name="com_name" id="comName" onChange="getSupplier(this.value)">
                      <option value="">Supplier Name</option>
                      <?php
                      //Load All suppliers
                      $ret = "SELECT * FROM  rpos_company ";
                      $stmt = $mysqli->prepare($ret);
                      $stmt->execute();
                      $res = $stmt->get_result();
                      while ($com = $res->fetch_object()) {
                      ?>
                        <option><?php echo $com->com_name; ?></option>
                      <?php } ?>
                    </select>
                    <input type="hidden" name="stock_id" value="<?php echo $stockid; ?>" class="form-control">
                  </div>
                  <div class="col-md-6">
                      <label>Supplier ID</label>
                      <input type="text" name="com_id" readonly id="comID" class="form-control">
                  </div>
                      </div>
                  <div class="form-row">
                  <div class="col-md-6">
                    <label>Product Name</label>
                    <select class="form-control" name="prod_name" id="prodName" onChange="getProduct(this.value)">
                      <option value="">Product Name</option>
                      <?php
                      //Load All Product
                      $ret = "SELECT * FROM  rpos_products ";
                      $stmt = $mysqli->prepare($ret);
                      $stmt->execute();
                      $res = $stmt->get_result();
                      while ($com = $res->fetch_object()) {
                      ?>
                        <option><?php echo $com->prod_name; ?></option>
                      <?php } ?>
                    </select>
                    <input type="hidden" name="trn_id" value="<?php echo $trnid; ?>" class="form-control">
                    </div>

                  <div class="col-md-6">
                    <label>Product ID</label>
                    <input type="text" name="prod_id" readonly id="prodID" class="form-control">
                  </div>
                </div>
                  <div class="form-row">
                    
                    <div class="col-md-6 mt-2">
                      <label>Product Quantity</label>
                      <input type="text" name="prod_qty" class="form-control" >
                    </div>
                    <div class="col-md-6 mt-2">
                      <label>Product Rate ($)</label>
                      <input type="text" name="prod_price"  class="form-control">
                    </div>
                  </div>
                  <div class="form-row">
                  <div class="col-md-6 mt-3">
                      <label>Transport Cost ($)</label>
                      <input type="text" name="trans_cost" class="form-control">
                    </div>
                    <div class="col-md-6 mt-3">
                      <label>Labour Cost ($)</label>
                      <input type="text" name="lab_cost"  class="form-control">
                    </div>
                  </div>
                <br>
                <div class="form-row">
                  <div class="col-md-6">
                    <input type="submit" name="make" value="Add to Stock" class="btn btn-success" >
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <?php
      require_once('partials/_footer.php');
      ?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>

</html>